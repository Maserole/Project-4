package com.expleo.project4.extraClasses;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class db_Connection {


    private static String database = "";

    static ArrayList<String> myMessage = new ArrayList<>();
    static File db_File;
    private static ResultSet myResultSet = null;
    public static int artistId = 0;
    public static String artistName="Black Sabbath";
    static  String table1 = "artists";
    static String table2 = "albums";
    private static Connection conn;


    //Method To Create Database Connection
    public static Connection getConnection(String db_name){

        String url = "jdbc:sqlite:C:\\Users\\7390\\IdeaProjects\\JhbGrads201905_ProjectDay4_Maserole\\"+db_name;
        try {
            conn= DriverManager.getConnection(url);

        } catch (SQLException e) {

            System.out.println("Error, "+e.getMessage());

        }
        return conn;
    }

    //Method To Manipulate Database
    public static void databaseManipulation(String databaseName){


        if (DB_Exist(databaseName)) {               //Checking If The Database Exist
            if(checkIfTablesExist(table1)){
                if(checkIfTablesExist(table2)){
                    if(checkDataOnTable1(artistName, table1)){
                        if(checkDataOnTable2(table2)){

                        }else{

                            try {

                                assertThat(true,is(checkDataOnTable2(table2)));
                            }catch(AssertionError e){

                                myMessage.add(artistName+" Does Not Have Albums Available In "+table2+" table.");
                            }
                        }
                    }else{

                        //
                        try {

                            assertThat(true,is(checkDataOnTable1(artistName,table1)));
                        }catch(AssertionError e){

                            myMessage.add(artistName+" Does Not Exist In "+table1+" table.");
                        }
                    }
                }else{

                    ////Catching Error If The Table Does Not Exist In The Database.

                    try {

                        assertThat(true,is(checkIfTablesExist(table2)));
                    }catch (AssertionError e){

                        myMessage.add(table2+" Does Not Exist In " + databaseName +" database");
                    }
                }
            }else{

                //Catching Error If The Table Does Not Exist In The Database.
                try {

                    assertThat(true,is(checkIfTablesExist(table1)));
                }catch (AssertionError e){

                    myMessage.add(table1+" Does Not Exist In " + databaseName +" database");
                }
            }
        } else {

            ////Catching Error If The Database Does Not Exist.
            try {

                assertThat(true, is(DB_Exist(databaseName)));
            } catch (AssertionError e) {

                myMessage.add(databaseName+"The DataBase Does Not Exist");
            }
        }
    }

    //Method To Check If The Database Exist In The Directory
    public static Boolean DB_Exist(String dbase){

        database = dbase+".db";
        db_File = new File(database);

        boolean itExist = false;

        if(db_File.exists()==true){
            itExist = true;
        }

        return itExist;
    }

    //Checking If The Tables Provided Exist In The Database
    public static boolean checkIfTablesExist(String tableName) {

        conn = getConnection(database);
        int numberOfRows = 0;

        String sql = "select count(*) as Total from "+tableName;
        PreparedStatement myStatement;

        boolean tableExist = false;

        try {

            myStatement = conn.prepareStatement(sql);
            myResultSet = myStatement.executeQuery();
            numberOfRows = myResultSet.getInt("Total");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(numberOfRows != 0){

            tableExist = true;
        }

        return tableExist;
    }

    //Checking If The Artist Exist In The Artist Table
    public static boolean checkDataOnTable1(String artist,String table){

        String sql = "select * from "+table+" where name = '"+artist+"'";
        PreparedStatement myStatement;

        boolean itExist = false;


        try {

            myStatement = conn.prepareStatement(sql);

            if(myStatement.execute()){

                itExist = true;
                myResultSet = myStatement.executeQuery();
                artistId = myResultSet.getInt("ArtistId");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }



        return itExist;
    }

    //Method To Check If The Artist Have Albums In Album Table
    public static boolean checkDataOnTable2(String tableName){

        String sql = "select * from "+tableName+" where ArtistId="+artistId;
        PreparedStatement myStatement;

        //String sql1 = "select count(*)'Number Of Albums' from "+tableName+" where ArtistId="+artistId;
        //PreparedStatement myStatement1;

        boolean itExist = false;

        try {

            myStatement = conn.prepareStatement(sql);
            //myStatement1 = conn.prepareStatement(sql1);

            //myResultSet = myStatement1.executeQuery();
            //numberOfRowsReturned = myResultSet.getInt("Number Of Albums");
            if(myStatement.execute()){

                itExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return itExist;
    }

    //Method To Add Albums Into An Array
    public static ArrayList<String> getAlbums() {

        String sql = "select * from "+table2+" where ArtistId="+artistId;
        PreparedStatement myStatement;

        ArrayList<String>Album_Title = new ArrayList<>();
        String myAlbums="";
        try {

            myStatement = conn.prepareStatement(sql);
            myResultSet = myStatement.executeQuery();

            while(myResultSet.next()){

                myAlbums = myResultSet.getString("Title");
                Album_Title.add(myAlbums);
            }

        }catch (SQLException e){

            e.printStackTrace();
        }

        return Album_Title;
    }

    //Method To Delete For The Tables
    public static void deleteEntriesFromTables() {

        if(deletefromtable1()){
            if(deleteFromTable2()){

            }else{

                try {

                    assertThat(true,is(deleteFromTable2()));
                }catch (AssertionError e){

                    myMessage.add("Unable To Delete Data From Artist Table.");
                }
            }
        }else{

            try {

                assertThat(true,is(deletefromtable1()));
            }catch (AssertionError e){

                myMessage.add("Unable To Delete Data From Album Table.");
            }
        }
    }

    public static boolean deletefromtable1(){

        String sql = "Delete from "+table2+" where ArtistId="+artistId;
        PreparedStatement myStatement;

        boolean deleted = false;

        try {

            myStatement=conn.prepareStatement(sql);

            if(myStatement.execute()){

                deleted = true;
            }

        }catch (SQLException e){

            e.printStackTrace();
        }

        return deleted;
    }

    private static boolean deleteFromTable2() {

        String sql = "Delete from "+table1+" where name='"+artistName+"'";
        PreparedStatement myStatement;

        boolean deleted = false;

        try {

            myStatement=conn.prepareStatement(sql);

            if(myStatement.execute()){

                deleted = true;
            }

        }catch (SQLException e) {

            e.printStackTrace();
        }

        return deleted;
    }

    public static ArrayList<String> getMyMessage() {
        return myMessage;
    }
}
