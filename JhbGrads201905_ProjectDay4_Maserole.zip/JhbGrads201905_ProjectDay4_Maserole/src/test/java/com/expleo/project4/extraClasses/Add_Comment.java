package com.expleo.project4.extraClasses;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.ArrayList;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class Add_Comment {

    private static JsonObject jsonObject;
    private static RequestSpecification request;
    private static String url;
    private static Response response;


    public static void setupRestfullService() {

        jsonObject = new JsonObject();
        request = given().contentType("application/json");
        url = jsonDatabase.getUrl();
    }

    public static void submitNewComment(ArrayList<String>albums, String name) {

        setupRestfullService();

        System.out.println("Size Of Array: "+albums.size());
        for (int i = 0; i < albums.size(); i++) {

            String comment = name + " : " + albums.get(i);
            jsonObject.addProperty("body",comment);
            jsonObject.addProperty("postId","1");
            request = request.body(jsonObject).when();
            response = (Response) request.post(url+"/comments");
        }

    }

    public static void verifyReturnCode(int returnCode) {

        request.then().statusCode(returnCode);
        assertThat(returnCode,equalTo(response.getStatusCode()));
    }
}
