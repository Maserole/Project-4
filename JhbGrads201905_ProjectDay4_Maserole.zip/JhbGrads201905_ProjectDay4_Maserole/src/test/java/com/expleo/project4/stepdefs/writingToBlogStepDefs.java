package com.expleo.project4.stepdefs;
import com.expleo.project4.extraClasses.db_Connection;
import com.expleo.project4.steps.writingToBlogSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class writingToBlogStepDefs {


    @Steps
    writingToBlogSteps mySteps; //Creating An Actor

    @Given("^I Have Chinook Database With Data In It$")
    public void i_Have_Chinook_Database_With_Data_In_It(){

        mySteps.databaseManipulation();
    }

    @Given("^I Have Json Blog Database$")
    public void i_Have_Json_Blog_Database(){

        mySteps.checkIfBlogDatabaseExist();
    }

    @When("^I Pull Data From Chinook Database$")
    public void i_Pull_Data_From_Chinook_Database(){

        mySteps.getData();
    }

    @When("^Write To Json Database$")
    public void write_To_Json_Database(){

        mySteps.writeToBlog();
    }

    @When("^Delete From Chinook Database$")
    public void delete_From_Chinook_Database(){

        mySteps.deleteFromTheTables();
    }

    @Then("^Should Run Successfully With Report Created$")
    public void should_Run_Successfully_With_Report_Created(){

        mySteps.printMsg(String.valueOf(db_Connection.getMyMessage()));
    }
}
