package com.expleo.project4.steps;
import com.expleo.project4.extraClasses.Add_Comment;
import com.expleo.project4.extraClasses.db_Connection;
import com.expleo.project4.extraClasses.jsonDatabase;
import net.thucydides.core.annotations.Step;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


public class writingToBlogSteps {


    private static String databaseName = "chinook"; //Database Name

    //Blog Database
    private String json_db = "db";

    @Step("Checking If Database Exist.")
    public void databaseManipulation() {

        db_Connection.databaseManipulation(databaseName);

    }

    @Step("Checking If Json Blog Database Exist.")
    public void checkIfBlogDatabaseExist() {

        jsonDatabase.jsonDB_Manipulation(json_db);
    }

    @Step("Getting Albums From Album Table")
    public void getData() {

        db_Connection.getAlbums();
    }

    @Step("Writting To A Blog By Adding Albums Of An Artist")
    public void writeToBlog() {

        Add_Comment.submitNewComment(db_Connection.getAlbums(),db_Connection.artistName);
        Add_Comment.verifyReturnCode(201);
    }

    @Step("Deleting From The Tables")
    public void deleteFromTheTables() {

        db_Connection.deleteEntriesFromTables();
    }

    @Step("{0}")
    public void printMsg(String msg){

    }

}
