package com.expleo.project4.extraClasses;
import java.io.File;
import java.util.ArrayList;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.assertThat;



public class jsonDatabase {

    private static String DB_json="";
    static File jsonFile;
    static ArrayList<String> myMessage = new ArrayList<>();


    public static void jsonDB_Manipulation(String json_db){


        try{

            assertThat(true,is(json_database(json_db)));

        }catch(AssertionError e){

            myMessage.add("Json Database Does Not Exist.");
        }

    }

    //Checking If Json Database Exist.
    public static boolean json_database(String json_db) {

        DB_json = json_db+".json";
        jsonFile = new File(DB_json);

        boolean itExist = false;

        if(jsonFile.exists()){

            itExist = true;
        }

        return itExist;
    }

    public static String getUrl() {

        String url = "http://localhost:3000";
        return url;
    }

}
